﻿namespace _19Kayami72CEduc
{
    partial class frmFrase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnMata = new System.Windows.Forms.Button();
            this.btnVive = new System.Windows.Forms.Button();
            this.btnNa = new System.Windows.Forms.Button();
            this.btnOnça = new System.Windows.Forms.Button();
            this.btnA = new System.Windows.Forms.Button();
            this.btnPintada = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblResposta = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.btnLimpa = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(116, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(551, 70);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ordene a Frase";
            // 
            // btnMata
            // 
            this.btnMata.BackColor = System.Drawing.Color.Cyan;
            this.btnMata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMata.Location = new System.Drawing.Point(322, 134);
            this.btnMata.Name = "btnMata";
            this.btnMata.Size = new System.Drawing.Size(80, 50);
            this.btnMata.TabIndex = 1;
            this.btnMata.Text = "&Mata";
            this.btnMata.UseVisualStyleBackColor = false;
            this.btnMata.Click += new System.EventHandler(this.btnMata_Click);
            // 
            // btnVive
            // 
            this.btnVive.BackColor = System.Drawing.Color.Cyan;
            this.btnVive.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVive.Location = new System.Drawing.Point(494, 134);
            this.btnVive.Name = "btnVive";
            this.btnVive.Size = new System.Drawing.Size(80, 50);
            this.btnVive.TabIndex = 2;
            this.btnVive.Text = "&Vive";
            this.btnVive.UseVisualStyleBackColor = false;
            this.btnVive.Click += new System.EventHandler(this.btnVive_Click);
            // 
            // btnNa
            // 
            this.btnNa.BackColor = System.Drawing.Color.Cyan;
            this.btnNa.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNa.Location = new System.Drawing.Point(666, 134);
            this.btnNa.Name = "btnNa";
            this.btnNa.Size = new System.Drawing.Size(80, 50);
            this.btnNa.TabIndex = 3;
            this.btnNa.Text = "&Na";
            this.btnNa.UseVisualStyleBackColor = false;
            this.btnNa.Click += new System.EventHandler(this.btnNa_Click);
            // 
            // btnOnça
            // 
            this.btnOnça.BackColor = System.Drawing.Color.Cyan;
            this.btnOnça.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOnça.Location = new System.Drawing.Point(240, 134);
            this.btnOnça.Name = "btnOnça";
            this.btnOnça.Size = new System.Drawing.Size(80, 50);
            this.btnOnça.TabIndex = 4;
            this.btnOnça.Text = "&Onça";
            this.btnOnça.UseVisualStyleBackColor = false;
            this.btnOnça.Click += new System.EventHandler(this.btnOnça_Click);
            // 
            // btnA
            // 
            this.btnA.BackColor = System.Drawing.Color.Cyan;
            this.btnA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnA.Location = new System.Drawing.Point(580, 134);
            this.btnA.Name = "btnA";
            this.btnA.Size = new System.Drawing.Size(80, 50);
            this.btnA.TabIndex = 5;
            this.btnA.Text = "&A";
            this.btnA.UseVisualStyleBackColor = false;
            this.btnA.Click += new System.EventHandler(this.btnA_Click);
            // 
            // btnPintada
            // 
            this.btnPintada.BackColor = System.Drawing.Color.Cyan;
            this.btnPintada.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPintada.Location = new System.Drawing.Point(408, 134);
            this.btnPintada.Name = "btnPintada";
            this.btnPintada.Size = new System.Drawing.Size(80, 50);
            this.btnPintada.TabIndex = 6;
            this.btnPintada.Text = "&Pintada";
            this.btnPintada.UseVisualStyleBackColor = false;
            this.btnPintada.Click += new System.EventHandler(this.btnPintada_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(260, 241);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(478, 39);
            this.label2.TabIndex = 7;
            this.label2.Text = ".........................................................";
            // 
            // lblResposta
            // 
            this.lblResposta.Font = new System.Drawing.Font("MV Boli", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResposta.Location = new System.Drawing.Point(279, 223);
            this.lblResposta.Name = "lblResposta";
            this.lblResposta.Size = new System.Drawing.Size(430, 36);
            this.lblResposta.TabIndex = 8;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::_19Kayami72CEduc.Properties.Resources.onça_removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(12, 103);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(185, 156);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // btnEnviar
            // 
            this.btnEnviar.BackColor = System.Drawing.Color.Red;
            this.btnEnviar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnviar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnEnviar.Location = new System.Drawing.Point(12, 338);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(169, 63);
            this.btnEnviar.TabIndex = 13;
            this.btnEnviar.Text = "&Enviar";
            this.btnEnviar.UseVisualStyleBackColor = false;
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click);
            // 
            // btnLimpa
            // 
            this.btnLimpa.BackColor = System.Drawing.Color.Blue;
            this.btnLimpa.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpa.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnLimpa.Location = new System.Drawing.Point(254, 338);
            this.btnLimpa.Name = "btnLimpa";
            this.btnLimpa.Size = new System.Drawing.Size(169, 63);
            this.btnLimpa.TabIndex = 14;
            this.btnLimpa.Text = "&Limpar";
            this.btnLimpa.UseVisualStyleBackColor = false;
            this.btnLimpa.Click += new System.EventHandler(this.btnLimpa_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.BackColor = System.Drawing.Color.PowderBlue;
            this.btnFechar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFechar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnFechar.Location = new System.Drawing.Point(510, 338);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(169, 63);
            this.btnFechar.TabIndex = 16;
            this.btnFechar.Text = "&Fechar";
            this.btnFechar.UseVisualStyleBackColor = false;
            this.btnFechar.Visible = false;
            this.btnFechar.Click += new System.EventHandler(this.btnProximo_Click);
            // 
            // frmFrase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.btnLimpa);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblResposta);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnPintada);
            this.Controls.Add(this.btnA);
            this.Controls.Add(this.btnOnça);
            this.Controls.Add(this.btnNa);
            this.Controls.Add(this.btnVive);
            this.Controls.Add(this.btnMata);
            this.Controls.Add(this.label1);
            this.Name = "frmFrase";
            this.Text = "Atividade Frase";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnMata;
        private System.Windows.Forms.Button btnVive;
        private System.Windows.Forms.Button btnNa;
        private System.Windows.Forms.Button btnOnça;
        private System.Windows.Forms.Button btnA;
        private System.Windows.Forms.Button btnPintada;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblResposta;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnEnviar;
        private System.Windows.Forms.Button btnLimpa;
        private System.Windows.Forms.Button btnFechar;
    }
}