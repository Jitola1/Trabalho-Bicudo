﻿namespace _19Kayami72CEduc
{
    partial class frmPalavra
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pctFoto = new System.Windows.Forms.PictureBox();
            this.btnMa = new System.Windows.Forms.Button();
            this.btnPa = new System.Windows.Forms.Button();
            this.btnCo = new System.Windows.Forms.Button();
            this.btnPe = new System.Windows.Forms.Button();
            this.btnPu = new System.Windows.Forms.Button();
            this.btnMu = new System.Windows.Forms.Button();
            this.btnCa = new System.Windows.Forms.Button();
            this.btnMe = new System.Windows.Forms.Button();
            this.btnCu = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblResposta = new System.Windows.Forms.Label();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.btnLimpa = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnProximo = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pctFoto)).BeginInit();
            this.SuspendLayout();
            // 
            // pctFoto
            // 
            this.pctFoto.Image = global::_19Kayami72CEduc.Properties.Resources.maco;
            this.pctFoto.Location = new System.Drawing.Point(24, 51);
            this.pctFoto.Name = "pctFoto";
            this.pctFoto.Size = new System.Drawing.Size(258, 189);
            this.pctFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctFoto.TabIndex = 0;
            this.pctFoto.TabStop = false;
            // 
            // btnMa
            // 
            this.btnMa.BackColor = System.Drawing.Color.Cyan;
            this.btnMa.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMa.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnMa.Location = new System.Drawing.Point(316, 51);
            this.btnMa.Name = "btnMa";
            this.btnMa.Size = new System.Drawing.Size(127, 62);
            this.btnMa.TabIndex = 1;
            this.btnMa.Text = "&Ma";
            this.btnMa.UseVisualStyleBackColor = false;
            this.btnMa.Click += new System.EventHandler(this.btnMa_Click);
            // 
            // btnPa
            // 
            this.btnPa.BackColor = System.Drawing.Color.Cyan;
            this.btnPa.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPa.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnPa.Location = new System.Drawing.Point(316, 187);
            this.btnPa.Name = "btnPa";
            this.btnPa.Size = new System.Drawing.Size(127, 62);
            this.btnPa.TabIndex = 2;
            this.btnPa.Text = "&Pa";
            this.btnPa.UseVisualStyleBackColor = false;
            this.btnPa.Click += new System.EventHandler(this.btnPa_Click);
            // 
            // btnCo
            // 
            this.btnCo.BackColor = System.Drawing.Color.Cyan;
            this.btnCo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCo.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnCo.Location = new System.Drawing.Point(449, 187);
            this.btnCo.Name = "btnCo";
            this.btnCo.Size = new System.Drawing.Size(127, 62);
            this.btnCo.TabIndex = 3;
            this.btnCo.Text = "&Co";
            this.btnCo.UseVisualStyleBackColor = false;
            this.btnCo.Click += new System.EventHandler(this.btnCo_Click);
            // 
            // btnPe
            // 
            this.btnPe.BackColor = System.Drawing.Color.Cyan;
            this.btnPe.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPe.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnPe.Location = new System.Drawing.Point(582, 187);
            this.btnPe.Name = "btnPe";
            this.btnPe.Size = new System.Drawing.Size(127, 62);
            this.btnPe.TabIndex = 4;
            this.btnPe.Text = "&Pe";
            this.btnPe.UseVisualStyleBackColor = false;
            this.btnPe.Click += new System.EventHandler(this.btnPe_Click);
            // 
            // btnPu
            // 
            this.btnPu.BackColor = System.Drawing.Color.Cyan;
            this.btnPu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPu.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnPu.Location = new System.Drawing.Point(582, 119);
            this.btnPu.Name = "btnPu";
            this.btnPu.Size = new System.Drawing.Size(127, 62);
            this.btnPu.TabIndex = 5;
            this.btnPu.Text = "&Pu";
            this.btnPu.UseVisualStyleBackColor = false;
            this.btnPu.Click += new System.EventHandler(this.btnPu_Click);
            // 
            // btnMu
            // 
            this.btnMu.BackColor = System.Drawing.Color.Cyan;
            this.btnMu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMu.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnMu.Location = new System.Drawing.Point(449, 119);
            this.btnMu.Name = "btnMu";
            this.btnMu.Size = new System.Drawing.Size(127, 62);
            this.btnMu.TabIndex = 6;
            this.btnMu.Text = "&Mu";
            this.btnMu.UseVisualStyleBackColor = false;
            this.btnMu.Click += new System.EventHandler(this.btnMu_Click);
            // 
            // btnCa
            // 
            this.btnCa.BackColor = System.Drawing.Color.Cyan;
            this.btnCa.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCa.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnCa.Location = new System.Drawing.Point(316, 119);
            this.btnCa.Name = "btnCa";
            this.btnCa.Size = new System.Drawing.Size(127, 62);
            this.btnCa.TabIndex = 7;
            this.btnCa.Text = "&Ca";
            this.btnCa.UseVisualStyleBackColor = false;
            this.btnCa.Click += new System.EventHandler(this.btnCa_Click);
            // 
            // btnMe
            // 
            this.btnMe.BackColor = System.Drawing.Color.Cyan;
            this.btnMe.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMe.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnMe.Location = new System.Drawing.Point(582, 51);
            this.btnMe.Name = "btnMe";
            this.btnMe.Size = new System.Drawing.Size(127, 62);
            this.btnMe.TabIndex = 8;
            this.btnMe.Text = "&Me";
            this.btnMe.UseVisualStyleBackColor = false;
            this.btnMe.Click += new System.EventHandler(this.btnMe_Click);
            // 
            // btnCu
            // 
            this.btnCu.BackColor = System.Drawing.Color.Cyan;
            this.btnCu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCu.ForeColor = System.Drawing.Color.DarkBlue;
            this.btnCu.Location = new System.Drawing.Point(449, 51);
            this.btnCu.Name = "btnCu";
            this.btnCu.Size = new System.Drawing.Size(127, 62);
            this.btnCu.TabIndex = 9;
            this.btnCu.Text = "&Cu";
            this.btnCu.UseVisualStyleBackColor = false;
            this.btnCu.Click += new System.EventHandler(this.btnCu_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(45, 282);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 38);
            this.label1.TabIndex = 10;
            this.label1.Text = "...................................................";
            // 
            // lblResposta
            // 
            this.lblResposta.Font = new System.Drawing.Font("MV Boli", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResposta.Location = new System.Drawing.Point(54, 258);
            this.lblResposta.Name = "lblResposta";
            this.lblResposta.Size = new System.Drawing.Size(174, 37);
            this.lblResposta.TabIndex = 11;
            // 
            // btnEnviar
            // 
            this.btnEnviar.BackColor = System.Drawing.Color.Red;
            this.btnEnviar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnviar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnEnviar.Location = new System.Drawing.Point(59, 323);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(169, 63);
            this.btnEnviar.TabIndex = 12;
            this.btnEnviar.Text = "Enviar";
            this.btnEnviar.UseVisualStyleBackColor = false;
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click);
            // 
            // btnLimpa
            // 
            this.btnLimpa.BackColor = System.Drawing.Color.Blue;
            this.btnLimpa.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpa.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnLimpa.Location = new System.Drawing.Point(329, 323);
            this.btnLimpa.Name = "btnLimpa";
            this.btnLimpa.Size = new System.Drawing.Size(169, 63);
            this.btnLimpa.TabIndex = 13;
            this.btnLimpa.Text = "Limpar";
            this.btnLimpa.UseVisualStyleBackColor = false;
            this.btnLimpa.Click += new System.EventHandler(this.btnLimpa_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(90, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(591, 42);
            this.label2.TabIndex = 14;
            this.label2.Text = "Qual o nome do animal?";
            // 
            // btnProximo
            // 
            this.btnProximo.BackColor = System.Drawing.Color.PowderBlue;
            this.btnProximo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProximo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnProximo.Location = new System.Drawing.Point(566, 323);
            this.btnProximo.Name = "btnProximo";
            this.btnProximo.Size = new System.Drawing.Size(169, 63);
            this.btnProximo.TabIndex = 15;
            this.btnProximo.Text = "Proximo";
            this.btnProximo.UseVisualStyleBackColor = false;
            this.btnProximo.Visible = false;
            this.btnProximo.Click += new System.EventHandler(this.btnProximo_Click);
            // 
            // frmPalavra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnProximo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnLimpa);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.lblResposta);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCu);
            this.Controls.Add(this.btnMe);
            this.Controls.Add(this.btnCa);
            this.Controls.Add(this.btnMu);
            this.Controls.Add(this.btnPu);
            this.Controls.Add(this.btnPe);
            this.Controls.Add(this.btnCo);
            this.Controls.Add(this.btnPa);
            this.Controls.Add(this.btnMa);
            this.Controls.Add(this.pctFoto);
            this.Name = "frmPalavra";
            this.Text = "Atividade Palavra";
            ((System.ComponentModel.ISupportInitialize)(this.pctFoto)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pctFoto;
        private System.Windows.Forms.Button btnMa;
        private System.Windows.Forms.Button btnPa;
        private System.Windows.Forms.Button btnCo;
        private System.Windows.Forms.Button btnPe;
        private System.Windows.Forms.Button btnPu;
        private System.Windows.Forms.Button btnMu;
        private System.Windows.Forms.Button btnCa;
        private System.Windows.Forms.Button btnMe;
        private System.Windows.Forms.Button btnCu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblResposta;
        private System.Windows.Forms.Button btnEnviar;
        private System.Windows.Forms.Button btnLimpa;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnProximo;
    }
}

