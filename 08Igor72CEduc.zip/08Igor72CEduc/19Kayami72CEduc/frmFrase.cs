﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _19Kayami72CEduc
{
    public partial class frmFrase : Form
    {
        string resp = "&A &Onça &Pintada &Vive &Na &Mata ";
        public frmFrase()
        {
            InitializeComponent();
        }

        private void btnOnça_Click(object sender, EventArgs e)
        {
            lblResposta.Text += btnOnça.Text + " ";
            btnOnça.BackColor = Color.White;
            btnOnça.Visible = false;

        }

        private void btnMata_Click(object sender, EventArgs e)
        {

            lblResposta.Text += btnMata.Text + " ";
            btnMata.BackColor = Color.White;
            btnMata.Visible = false;
        }

        private void btnPintada_Click(object sender, EventArgs e)
        {

            lblResposta.Text += btnPintada.Text + " ";
            btnPintada.BackColor = Color.White;
            btnPintada.Visible = false;
        }

        private void btnVive_Click(object sender, EventArgs e)
        {

            lblResposta.Text += btnVive.Text + " ";
            btnVive.BackColor = Color.White;
            btnVive.Visible = false;
        }

        private void btnA_Click(object sender, EventArgs e)
        {

            lblResposta.Text += btnA.Text + " ";
            btnA.BackColor = Color.White;
            btnA.Visible = false;

        }

        private void btnNa_Click(object sender, EventArgs e)
        {

            lblResposta.Text += btnNa.Text + " ";
            btnNa.BackColor = Color.White;
            btnNa.Visible = false;
        }

        private void btnLimpa_Click(object sender, EventArgs e)
        {
            lblResposta.Text = "";
            Limparbotao();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            string guarda = "";
            guarda = lblResposta.Text;
            if (guarda == resp)
            {
                DialogResult caixa;
                caixa = MessageBox.Show("Parabéns Você acertou",
                                        "Exercicio palavra",
                                         MessageBoxButtons.OK,
                                         MessageBoxIcon.Information);
                lblResposta.Text = "";

                Limparbotao();
                DialogResult resposta;
                resposta = MessageBox.Show("A atividade acabou, agora você pode fechar a atividade",
                                "Exercico Frase",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Question);
                btnFechar.Visible = true;
            }
            if (guarda != resp)
            {
                DialogResult caixa;
                caixa = MessageBox.Show("Algo não está certo",
                                        "Exercicio palavra",
                                         MessageBoxButtons.OK,
                                         MessageBoxIcon.Hand);
                lblResposta.Text = "";

                Limparbotao();
            }
        }
        public void Limparbotao()
        {
            btnNa.BackColor = Color.Cyan;
            btnPintada.BackColor = Color.Cyan;
            btnVive.BackColor = Color.Cyan;
            btnMata.BackColor = Color.Cyan;
            btnA.BackColor = Color.Cyan;
            btnOnça.BackColor = Color.Cyan;
            btnNa.Visible = true;
            btnA.Visible = true;
            btnVive.Visible = true;
            btnPintada.Visible = true;
            btnMata.Visible = true;
            btnOnça.Visible = true;
        }

        private void btnProximo_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
