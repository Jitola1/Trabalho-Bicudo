﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _19Kayami72CEduc
{
    public partial class frmPalavra : Form
    {
        string maco = "&Ma&Ca&Co";
        public frmPalavra()
        {
            InitializeComponent();
        }

        private void btnMa_Click(object sender, EventArgs e)
        {
            lblResposta.Text += btnMa.Text;
            btnMa.BackColor = Color.White;
            btnMa.Visible = false;
        }

        private void btnCu_Click(object sender, EventArgs e)
        {
            lblResposta.Text += btnCu.Text;
            btnCu.BackColor = Color.White;
            btnCu.Visible = false;
        }

        private void btnMe_Click(object sender, EventArgs e)
        {
            lblResposta.Text += btnMe.Text;
            btnMe.BackColor = Color.White;
            btnMe.Visible = false;
        }

        private void btnCa_Click(object sender, EventArgs e)
        {
            lblResposta.Text += btnCa.Text;
            btnCa.BackColor = Color.White;
            btnCa.Visible = false;
        }

        private void btnMu_Click(object sender, EventArgs e)
        {
            lblResposta.Text += btnMu.Text;
            btnMu.BackColor = Color.White;
            btnMu.Visible = false;
        }

        private void btnPu_Click(object sender, EventArgs e)
        {
            lblResposta.Text += btnPu.Text;
            btnPu.BackColor = Color.White;
            btnPu.Visible = false;
        }

        private void btnPa_Click(object sender, EventArgs e)
        {
            lblResposta.Text += btnPa.Text; ;
            btnPa.BackColor = Color.White;
            btnPa.Visible = false;
        }

        private void btnCo_Click(object sender, EventArgs e)
        {
            lblResposta.Text += btnCo.Text;
            btnCo.BackColor = Color.White;
            btnCo.Visible = false;
        }

        private void btnPe_Click(object sender, EventArgs e)
        {
            lblResposta.Text += btnPe.Text;
            btnPe.BackColor = Color.White;
            btnPe.Visible = false;
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            string guarda = "";
            guarda = lblResposta.Text;
            if (guarda == maco)
            {
                DialogResult caixa;
                caixa = MessageBox.Show("Parabéns Você acertou, Clique no Botão 'Proximo' para continuar",
                                        "Exercicio palavra",
                                         MessageBoxButtons.OK,
                                         MessageBoxIcon.Information);
                lblResposta.Text = "";
                limparBotao();
                btnProximo.Visible = true;

            }
            if(guarda != maco)
            {
                DialogResult caixa;
                caixa = MessageBox.Show("Algo não está certo",
                                        "Exercicio palavra",
                                         MessageBoxButtons.OK,
                                         MessageBoxIcon.Hand);
                lblResposta.Text = "";
                limparBotao();
            }
        }

        private void btnLimpa_Click(object sender, EventArgs e)
        {
            lblResposta.Text = "";
            limparBotao();
        }

        public void limparBotao()
        {
            btnCa.BackColor = Color.Cyan;
            btnPa.BackColor = Color.Cyan;
            btnPu.BackColor = Color.Cyan;
            btnPe.BackColor = Color.Cyan;
            btnMu.BackColor = Color.Cyan;
            btnMe.BackColor = Color.Cyan;
            btnMa.BackColor = Color.Cyan;
            btnCu.BackColor = Color.Cyan;
            btnCo.BackColor = Color.Cyan;
            btnMa.Visible = true;
            btnPe.Visible = true;
            btnCo.Visible = true;
            btnPa.Visible = true;
            btnPu.Visible = true;
            btnMu.Visible = true;
            btnCa.Visible = true;
            btnCa.Visible = true;
            btnMe.Visible = true;
            btnCu.Visible = true;
            btnMa.Visible = true;
        }

        private void btnProximo_Click(object sender, EventArgs e)
        {
            frmFrase abrirfrase = new frmFrase();
            abrirfrase.ShowDialog();
            this.Close();
        }
    }
}
